from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'  # Change this to a random secret key for flash messages

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/contact")
def contact():
    return render_template("contact.html")

@app.route("/students")
def students():
    search = request.args.get('search', '')
    conn = sqlite3.connect('instance/students.db')
    c = conn.cursor()
    
    if search:
        c.execute('SELECT * FROM STUDENTS WHERE FULL_NAME LIKE ? ORDER BY FULL_NAME', (f'%{search}%',))
    else:
        c.execute('SELECT * FROM STUDENTS ORDER BY FULL_NAME')
    
    
    students_list = c.fetchall()
    conn.close()
    return render_template("students.html", students=students_list, search=search)

@app.route("/add_student", methods=['GET', 'POST'])
def add_student():
    if request.method == 'POST':
        name = request.form['name'].strip()
        email = request.form['email'].strip()
        phone = request.form.get('phone', '').strip()
        course = request.form.get('course', '').strip()
        
        # Basic validation
        if not name:
            flash('Full name is required!', 'error')
            return render_template("add_student.html")
        
        if email:  # Email is optional but if provided should be unique
            conn = sqlite3.connect('instance/students.db')
            c = conn.cursor()
            c.execute('SELECT STUDENT_ID FROM STUDENTS WHERE EMAIL = ?', (email,))
            if c.fetchone():
                conn.close()
                flash('Email already exists! Please use a different email.', 'error')
                return render_template("add_student.html")
            conn.close()
        
        try:
            conn = sqlite3.connect('instance/students.db')
            c = conn.cursor()
            c.execute('INSERT INTO STUDENTS (FULL_NAME, EMAIL) VALUES (?, ?)',(name, email if email else None))
         
            conn.commit()
            conn.close()
            flash('Student added successfully!', 'success')
            return redirect(url_for('students'))
        except sqlite3.Error as e:
            flash('Error adding student. Please try again.', 'error')
            return render_template("add_student.html")
    
    return render_template("add_student.html")


@app.route("/delete_student/<int:student_id>")
def delete_student(student_id):
    try:
        conn = sqlite3.connect('instance/students.db')
        c = conn.cursor()
        c.execute('DELETE FROM STUDENTS WHERE STUDENT_ID = ?', (student_id,))
        conn.commit()
        conn.close()
        flash('Student deleted successfully!', 'success')
    except sqlite3.Error:
        flash('Error deleting student. Please try again.', 'error')
    
    return redirect(url_for('students'))

@app.route("/contact_submit", methods=['POST'])
def contact_submit():
    name = request.form['name']
    email = request.form['email']
    message = request.form['message']
    
    # Basic validation
    if not name or not email or not message:
        flash('All fields are required!', 'error')
        return redirect(url_for('contact'))
    
    # Here you could save to database or send email
    flash(f'Thank you {name}! Your message has been received.', 'success')
    return redirect(url_for('contact'))

if __name__ == "__main__":
    app.run(debug=True)