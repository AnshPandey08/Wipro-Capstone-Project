import sqlite3
import os

# Ensure instance folder exists
os.makedirs("instance", exist_ok=True)

# Put database inside /instance/
db_path = os.path.join("instance", "students.db")
connection = sqlite3.connect(db_path)

with open("schema.sql") as f:
    connection.executescript(f.read())

connection.commit()
connection.close()

print(f"✅ Database initialized successfully at {db_path}")
