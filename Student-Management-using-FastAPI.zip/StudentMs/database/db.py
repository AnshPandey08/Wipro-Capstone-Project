import sqlite3

DB_PATH = "students.db"

def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row  # makes rows behave like dicts
    return conn

def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.executescript(open("schema.sql", "r").read())
    conn.commit()
    conn.close()
