from fastapi import FastAPI, Request, Form
from fastapi.responses import RedirectResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import sqlite3

# Initialize app
app = FastAPI()

# Static and templates setup
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

DB_NAME = "students.db"

# ---------------- DB FUNCTIONS ----------------
def init_db():
    with sqlite3.connect(DB_NAME) as conn:
        with open("schema.sql", "r") as f:
            conn.executescript(f.read())

def get_students(search=None):
    with sqlite3.connect(DB_NAME) as conn:
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        if search:
            cursor.execute("SELECT * FROM STUDENTS WHERE FULL_NAME LIKE ?", (f"%{search}%",))
        else:
            cursor.execute("SELECT * FROM STUDENTS")
        return cursor.fetchall()

def add_student(name, email):
    with sqlite3.connect(DB_NAME) as conn:
        cursor = conn.cursor()
        cursor.execute("INSERT INTO STUDENTS (FULL_NAME, EMAIL) VALUES (?, ?)", (name, email))
        conn.commit()

def delete_student(student_id):
    with sqlite3.connect(DB_NAME) as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM STUDENTS WHERE STUDENT_ID = ?", (student_id,))
        conn.commit()

# ---------------- ROUTES ----------------
@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/about", response_class=HTMLResponse)
async def about(request: Request):
    return templates.TemplateResponse("about.html", {"request": request})

@app.get("/contact", response_class=HTMLResponse)
async def contact(request: Request):
    return templates.TemplateResponse("contact.html", {"request": request})

@app.post("/contact_submit", response_class=HTMLResponse)
async def contact_submit(request: Request, name: str = Form(...), email: str = Form(...), message: str = Form(...)):
    print(f"Contact form submitted by {name} ({email}): {message}")
    return RedirectResponse("/contact", status_code=303)

@app.get("/students", response_class=HTMLResponse)
async def students(request: Request, search: str = None):
    students_list = get_students(search)
    return templates.TemplateResponse("students.html", {"request": request, "students": students_list, "search": search})

@app.post("/add_student", response_class=HTMLResponse)
async def add_student_route(request: Request, name: str = Form(...), email: str = Form(None)):
    add_student(name, email)
    return RedirectResponse("/students", status_code=303)

@app.get("/delete_student/{student_id}", response_class=HTMLResponse)
async def delete_student_route(request: Request, student_id: int):
    delete_student(student_id)
    return RedirectResponse("/students", status_code=303)

# Initialize DB on startup
init_db()


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host="127.0.0.1", port=8000, reload=True)
